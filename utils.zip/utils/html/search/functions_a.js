var searchData=
[
  ['section_182',['Section',['../classini_1_1_section.html#aaf3b8d7206f21a3e114aaeed685a9b72',1,'ini::Section::Section(const std::string &amp;section_name_init, const ValueMap *const values_init)'],['../classini_1_1_section.html#a90c20ebbae861424a63de113223f582e',1,'ini::Section::Section(const Section &amp;original)']]]
];
