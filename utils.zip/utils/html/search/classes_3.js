var searchData=
[
  ['incompatibleconversion_106',['IncompatibleConversion',['../classini_1_1_incompatible_conversion.html',1,'ini']]]
];
