var searchData=
[
  ['duplicateentry_102',['DuplicateEntry',['../classini_1_1_duplicate_entry.html',1,'ini']]],
  ['duplicatesection_103',['DuplicateSection',['../classini_1_1_duplicate_section.html',1,'ini']]]
];
