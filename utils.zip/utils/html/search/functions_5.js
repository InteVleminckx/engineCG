var searchData=
[
  ['incompatibleconversion_161',['IncompatibleConversion',['../classini_1_1_incompatible_conversion.html#ad24a5e74b957b52e04e557a114f64e60',1,'ini::IncompatibleConversion::IncompatibleConversion(const std::string &amp;section_name_init, const std::string &amp;entry_name_init, const std::string &amp;type_name_init)'],['../classini_1_1_incompatible_conversion.html#a1dd7c1b013f2d8e5278c1eda65eb499e',1,'ini::IncompatibleConversion::IncompatibleConversion(const IncompatibleConversion &amp;original)']]]
];
