var searchData=
[
  ['color_100',['Color',['../class_color.html',1,'Color'],['../classimg_1_1_color.html',1,'img::Color']]],
  ['configuration_101',['Configuration',['../classini_1_1_configuration.html',1,'ini']]]
];
