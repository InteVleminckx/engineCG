var searchData=
[
  ['unexpectedcharacter_183',['UnexpectedCharacter',['../classini_1_1_unexpected_character.html#a8b498fdadf20038b5bf5ce56f4504ecf',1,'ini::UnexpectedCharacter::UnexpectedCharacter(const std::istream::int_type character_init, const std::istream::pos_type position_init)'],['../classini_1_1_unexpected_character.html#a5d2c7d1df88068802356220ea69b49eb',1,'ini::UnexpectedCharacter::UnexpectedCharacter(const UnexpectedCharacter &amp;original)']]],
  ['unsupportedfiletypeexception_184',['UnsupportedFileTypeException',['../classimg_1_1_unsupported_file_type_exception.html#a27feee59d63dd3029943bd435cfa2353',1,'img::UnsupportedFileTypeException::UnsupportedFileTypeException(std::string const &amp;msg)'],['../classimg_1_1_unsupported_file_type_exception.html#a20ff4eeaaa1c03529d1b1f3e4ad5572d',1,'img::UnsupportedFileTypeException::UnsupportedFileTypeException(const UnsupportedFileTypeException &amp;original)']]]
];
