var searchData=
[
  ['green_205',['green',['../classimg_1_1_color.html#aa6568f91f582b017a554ad90e5821323',1,'img::Color']]]
];
