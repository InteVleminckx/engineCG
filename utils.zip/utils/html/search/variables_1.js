var searchData=
[
  ['blue_203',['blue',['../classimg_1_1_color.html#abb624b81ef463e08861884dfe3a679e3',1,'img::Color']]]
];
