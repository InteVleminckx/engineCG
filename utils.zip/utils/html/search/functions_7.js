var searchData=
[
  ['nonexistententry_165',['NonexistentEntry',['../classini_1_1_nonexistent_entry.html#a936a5c447833894e25d8147817256372',1,'ini::NonexistentEntry::NonexistentEntry(const std::string &amp;section_name_init, const std::string &amp;entry_name_init)'],['../classini_1_1_nonexistent_entry.html#adeb9199283a46e42b40d2e55bc0c4280',1,'ini::NonexistentEntry::NonexistentEntry(const NonexistentEntry &amp;original)']]]
];
