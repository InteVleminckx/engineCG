var indexSectionsWithContent =
{
  0: "abcdegilnoprstuvw~",
  1: "cdeilnpstuv",
  2: "il",
  3: "acdegilnopsuw~",
  4: "abdginrs",
  5: "cdiv",
  6: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends"
};

